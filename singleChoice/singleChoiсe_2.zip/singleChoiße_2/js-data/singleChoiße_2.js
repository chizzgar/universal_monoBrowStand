(() => {
  // массив входящих вариантов ответа (максимум 5-6 элементов),

  const answersData = [
    {
      id: 1,
      data: "8",
      audioSrc: 'sound/8_s.mp3',
    },
    {
      id: 2,
      data: "7",
      audioSrc: 'sound/7_s.mp3',
    },
    {
      id: 3,
      data: "10",
      audioSrc: 'sound/10_s.mp3',
    },
    {
      id: 4,
      data: "12",
      audioSrc: 'sound/12_s.mp3',
    },
    {
      id: 5,
      data: "9",
      audioSrc: 'sound/9_s.mp3',
    },
  ];

  // здесь указывается правильный ответ, он проверяется по полю date  в массиве
  const winVarTask = "10";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-1");

  // сама функция, которая запускается, здесь ничего менять не нужно
  renderSingleChoiceTextMarkup(answersData, winVarTask, taskWrapper);
})();






(() => {
  // массив входящих вариантов ответа (максимум 5-6 элементов),

  const answersData = [
    {
      id: 1,
      data: "Картошка",
      audioSrc: 'sound/kar.mp3',
    },
    {
      id: 2,
      data: "Капуста",
      audioSrc: 'sound/kap.mp3',
    },
    {
      id: 3,
      data: "Морковь",
      audioSrc: 'sound/mork.mp3',
    },
    // {
    //   id: 1,
    //   data: "Картошка",
    //   audioSrc: '',
    // },
    // {
    //   id: 2,
    //   data: "Капуста",
    //   audioSrc: '',
    // },
    // {
    //   id: 3,
    //   data: "Огурец",
    //   audioSrc: '',
    // },
  ];

  // здесь указывается правильный ответ, он проверяется по полю date  в массиве
  const winVarTask = "Морковь";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-2");

  // сама функция, которая запускается, здесь ничего менять не нужно
  renderSingleChoiceTextMarkup(answersData, winVarTask, taskWrapper);
})();
(() => {
  // массив входящих вариантов ответа (максимум 5-6 элементов),

  const answersData = [
    {
      id: 1,
      data: "фиолетовый круглый мячик",
      audioSrc: '',
    },
    {
      id: 2,
      data: "Зелёное пластиковое ведёрко",
      audioSrc: '',
    },
    {
      id: 3,
      data: "Разноцветная деревянная пирамидка",
      audioSrc: '',
    },
    {
      id: 1,
      data: "Грузовая машинка с прицепом",
      audioSrc: '',
    },
    {
      id: 2,
      data: "Жёлтый резиновый утёнок",
      audioSrc: '',
    },
    {
      id: 3,
      data: "Красный деревянный кубик",
      audioSrc: '',
    },
  ];

  // здесь указывается правильный ответ, он проверяется по полю data  в массиве
  const winVarTask = "фиолетовый круглый мячик";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-3");

  // сама функция, которая запускается, здесь ничего менять не нужно
  renderSingleChoiceTextMarkup(answersData, winVarTask, taskWrapper);
})();






function renderSingleChoiceTextMarkup(answersData, winVarTask, taskWrapper) {
  let answersItems = null;
  let finishAnswer = null;
  let currentSound;
  let isPlaying = false;


  // const wrapperWidth = taskWrapper.clientWidth;

  const answers = taskWrapper.querySelector(".task_answers");
  const reloadTaskBtn = taskWrapper.querySelector(".reloadTask");
  const checkingTaskBtn = taskWrapper.querySelector(".checkingTask");
  const checkTask = taskWrapper.querySelector(".checkTask");
  const chek_answerTxt = taskWrapper.querySelector(".chek_answer");


  function createMarcup() {
    answers.insertAdjacentHTML(
      "beforeend",
      insertAnswers(shuffleArr(answersData))
    );
  }

  createMarcup();


  const audioFiles = taskWrapper.querySelectorAll(".singleChoice_text_btn");
  const audioIcons = taskWrapper.querySelectorAll(
    ".buttonPlayPausePlayPause_wrap"
  );

  answersItems = answers.querySelectorAll(".task_answer");

  answers.addEventListener("click", onAnswerClick);
  reloadTaskBtn.addEventListener("click", onReloadBtnClick);
  checkingTaskBtn.addEventListener("click", onCheckTaskBtnClick);




  [...audioIcons].forEach((el) => {
    el.addEventListener("click", onSoundIconClick);
  });

  [...audioFiles].forEach((el) =>
    el.addEventListener("ended", (e) => {
      e.target
        .closest(".buttonPlayPausePlayPause_wrap")
        .classList.remove("buttonPlayPause--active");

      isPlaying = true;
      resetSound(currentSound);
    })
  );
  function onSoundIconClick(e) {
    findSoundAndPlayPause("sound-data", e.target);
  }

  function findSoundAndPlayPause(attrName, target) {
    const findedSound = [...audioFiles].find(
      (el) =>
        el.id === target.parentElement.attributes.getNamedItem(attrName).value
    );

    if (currentSound && currentSound.id === findedSound.id && !isPlaying) {
      currentSound.pause();
      isPlaying = true;
      removeActiveSoundCardClass();

      target.classList.remove("buttonPlayPause--active");
    } else if (
      currentSound &&
      currentSound.id === findedSound.id &&
      isPlaying
    ) {
      currentSound.play();
      isPlaying = false;

      target.classList.add("buttonPlayPause--active");
    } else {
      removeActiveSoundCardClass();

      target.classList.add("buttonPlayPause--active");
      resetSound(currentSound);
      isPlaying = false;

      currentSound = findedSound;
      currentSound.play();
    }
  }
  function removeActiveSoundCardClass() {
    const currentActiveCard = document.querySelector(
      ".buttonPlayPausePlayPause_wrap.buttonPlayPause--active"
    );

    if (currentActiveCard) {
      currentActiveCard.classList.remove("buttonPlayPause--active");
    }
  }


  function resetSound(currentSound) {
    if (currentSound) {
      currentSound.pause();
      currentSound.currentTime = 0;
      currentSound = null;
    }
  }


  function onAnswerClick(e) {
    if (e.target.classList.contains("task_answer")) {
      answersItems.forEach((item) => {
        if (finishAnswer) {
          finishAnswer.classList.remove("task_answer_active");
          finishAnswer.classList.remove("task_green");
          finishAnswer.classList.remove("task_red");
        }
        item.classList.remove("targetChoice_color");
      });
      e.target.classList.add("targetChoice_color");
      finishAnswer = e.target;

      checkingAnswerReset();
    }
  }

  function shuffleArr(arr) {
    return arr.sort(() => Math.random() - 0.5);
  }

  function insertAnswers(arr) {
    const widthText = arr.some((el) => el.data.length > 6);
    if (!widthText && arr.length > 5) {
      answers.classList.add("task_answers_width");
    }
    return arr
      .map((item) => {
        let elementWidth;
        let elWidthSmall = "";

        if (widthText) {
          if (arr.length > 4) {
            elementWidth = `"width: calc(100% / 3 - 10px)"`;
          } else if (arr.length < 4) {
            elementWidth = `"width: calc(100% / ${arr.length} - 10px)"`;
          } else if (arr.length === 4) {
            elementWidth = `"width: calc(100% / 2 - 10px)"`;
          }
        } else {
          elWidthSmall = ["task_answer_width", "task_answer_height"].join(" ");
        }

        const isSound =
          item.audioSrc &&
          `<div class='dnd_OneToOne_soundBox' sound-data="${item.id}" >
                <div class="buttonPlayPausePlayPause_wrap buttonPlayPause--play">
                    <div class="buttonPlayPause__shape buttonPlayPause__shape--one"></div>
                    <div class="buttonPlayPause__shape buttonPlayPause__shape--two"></div>
                    <audio class="singleChoice_text_btn" id="${item.id}" src="${item.audioSrc}">
                              Your browser does not support the
                              <code>audio</code> element.
                    </audio>
                </div>
            </div>`;


        return `
                  <div class="task_answer ${elWidthSmall} oneMultiChoice_border" style=${elementWidth}>
                  ${isSound}
                  ${item.data}
                  </div>
              `;
      })
      .join("");
  }

  function onReloadBtnClick() {
    if (finishAnswer) {
      finishAnswer.classList.remove("wrongChoice_answered");
      finishAnswer.classList.remove("rightChoice_answered");
      finishAnswer.classList.remove("targetChoice_color");
    }
    chek_answerTxt.firstElementChild !== null && chek_answerTxt.removeChild(chek_answerTxt.firstElementChild);
    checkingAnswerReset()
    finishAnswer = null;
  };

  function onCheckTaskBtnClick() {
    if (!finishAnswer) {
      return;
    }
    finishAnswer.classList.remove("task_answer_active");
    if (finishAnswer.innerText === winVarTask) {
      finishAnswer.classList.remove('targetChoice_color');
      finishAnswer.classList.add("rightChoice_answered");
      chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128516;&nbsp;&nbsp;Молодец!</div>';
      checkTask.classList.add('chek_answer_rightChoice_color');
      checkTask.classList.remove('chek_answer_wrongChoice_color');
    } else {
      if (finishAnswer) {
        finishAnswer.classList.remove('targetChoice_color');
        finishAnswer.classList.add("wrongChoice_answered");
        chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128528;&nbsp;&nbsp;Попробуй&nbsp;еще!</div>';
        checkTask.classList.add('chek_answer_wrongChoice_color');
        checkTask.classList.remove('chek_answer_rightChoice_color');
      }
    }
  };

  function checkingAnswerReset() {
    chek_answerTxt.innerHTML = "";
    checkTask.classList.remove('chek_answer_rightChoice_color');
    checkTask.classList.remove('chek_answer_wrongChoice_color');
  }
}
