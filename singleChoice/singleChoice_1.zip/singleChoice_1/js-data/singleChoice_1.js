(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [
        {
            id: 1,
            text: 'Тычинка',
            audio: ''
        },
        {
            id: 2,
            text: 'Пестик',
            audio: ''
        },
        {
            id: 3,
            text: 'Семя',
            audio: ''
        },
        {
            id: 4,
            text: 'Плод',
            audio: ''
        }
    ]
    //правильный ответ
    const rightAnswer = 'Семя'
    //уникальный id задания как в HTML
    const Id = '#ev_1_task-1'

    renderEV_1(data, Id, rightAnswer)
})();

(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [
        {
            id: 1,
            text: 'шапка снега',
            audio: 'sound/8045.mp3'
        },
        {
            id: 2,
            text: 'столовое серебро',
            audio: 'sound/8053.mp3'
        },
        {
            id: 3,
            text: 'чугунная голова',
            audio: 'sound/8060.mp3'
        },
        {
            id: 4,
            text: 'дождь барабанит по крыше',
            audio: 'sound/8067.mp3'
        },
    ]
    //правильный ответ
    const rightAnswer = 'Лингвистика — наука о языке.'
    //уникальный id задания как в HTML
    const Id = '#ev_1_task-2'

    renderEV_1(data, Id, rightAnswer)
})();

(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [
        {
            id: 1,
            text: 'М. В. Ломоносов — наш русский университет.',
            audio: ''
        },
        {
            id: 2,
            text: 'Многие явления в природе помогают предсказать погоду.',
            audio: ''
        },
        {
            id: 3,
            text: 'Самым дальним предком бумаги был камень.',
            audio: ''
        },
        {
            id: 4,
            text: 'Лингвистика — наука о языке.',
            audio: ''
        },
        {
            id: 5,
            text: 'Наука ускоряет наше движение вперёд.',
            audio: ''
        },
    ]
    //правильный ответ
    const rightAnswer = 'Лингвистика — наука о языке.'
    //уникальный id задания как в HTML
    const Id = '#ev_1_task-3'

    renderEV_1(data, Id, rightAnswer)
})();


(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [
        {
            id: 1,
            text: 'А знаете ли, я удивляюсь, как вы хорошо говорите по-русски. (И.С. Тургенев) (сложное, повеств., невоскл., 1: двусост., нераспр., полное, осложн. вводными словами со значением привлечения внимания собеседника; 2: двусост., распр., полное, неосложн.)',
            audio: ''
        },
        {
            id: 2,
            text: 'Он услал её, наконец, и после долгих колебаний решился отправиться к Калягиным. (И.С. Тургенев) (сложное, повеств., невоскл., 1: двусост., нераспр., полное, осложн. вводными словами, содержащими указания на связь мыслей; 2: двусост., распр., полное, неосложн.)',
            audio: ''
        },
        {
            id: 3,
            text: 'Казалось, вместе с вечерними парами отовсюду поднималась и даже с вышины лилась темнота. (И.С. Тургенев) (повеств., невоскл., простое, двусост., распр., полное, осложн. однородными сказуемыми и вводными словами со значением различной степени уверенности)',
            audio: ''
        },
    ]
    //правильный ответ
    const rightAnswer = 'Он услал её, наконец, и после долгих колебаний решился отправиться к Калягиным. (И.С. Тургенев) (сложное, повеств., невоскл., 1: двусост., нераспр., полное, осложн. вводными словами, содержащими указания на связь мыслей; 2: двусост., распр., полное, неосложн.)'
    //уникальный id задания как в HTML
    const Id = '#ev_1_task-4'

    renderEV_1(data, Id, rightAnswer)
})();

(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [{
        id: 1,
        text: 'Мимо белых колонн мы пошли посмотреть виноград,',
        audio: ''
    },
    {
        id: 2,
        text: 'Где воздушным стеклом обливаются сонные горы.',
        audio: ''
    },
    {
        id: 3,
        text: 'Я сказал: виноград, как старинная битва, живет,',
        audio: ''
    },
    {
        id: 4,
        text: 'Где курчавые всадники бьются в кудрявом порядке;',
        audio: ''
    },
    {
        id: 5,
        text: 'В каменистой Тавриде наука Эллады — и вот',
        audio: ''
    },
    {
        id: 6,
        text: 'Золотых десятин благородные, ржавые грядки.',
        audio: ''
    },
    ]
    //правильный ответ
    const rightAnswer = 'В каменистой Тавриде наука Эллады — и вот'
    //уникальный id задания
    const Id = '#ev_1_task-5'

    renderEV_1(data, Id, rightAnswer)
})();

(() => {
    //входящие данные
    //поле audio - опционально(если не надо оставляем пустые кавычки)
    const data = [{
        id: 1,
        text: 'Для речевой организации текста определяющими оказываются внешние, коммуникативные факторы. И потому порождение текста и его функционирование прагматически ориентированы, т.е. текст создается при возникновении определенной целеустановки и функционирует в определенных коммуникативных условиях.',
        audio: ''
    },
    {
        id: 2,
        text: 'Среди филологических дисциплин, в частности, редакционно-издательского и журналистского профиля, теория текста занимает одну из главных позиций. Это объясняется тем, что текст как объект исследования предстает здесь как вербальная информативная единица «в действии», т.е. обладающая прагматическими и функциональными качествами.',
        audio: ''
    },
    {
        id: 3,
        text: 'В настоящее время наиболее последовательной и гибкой представляется система текстов (их типология), основанием которой является теория функциональных стилей при учете коммуникативно-прагматических условий текстообразования',
        audio: ''
    },
    ]
    //правильный ответ
    const rightAnswer = 'В настоящее время наиболее последовательной и гибкой представляется система текстов (их типология), основанием которой является теория функциональных стилей при учете коммуникативно-прагматических условий текстообразования'
    //уникальный id задания
    const Id = '#ev_1_task-5'

    renderEV_1(data, Id, rightAnswer)
})();


function renderEV_1(data, Id, rightAnswer) {
    const task = document.querySelector(Id)
    const field = task.querySelector('.singleChoice_1')
    const reloadTaskBtn = task.querySelector('.reloadTask')
    const checkingTaskBtn = task.querySelector('.checkingTask')
    const chek_answerTxt = task.querySelector('.chek_answer')
    const checkTask = task.querySelector('.checkTask');

    let answer

    const playSoundsButon = (soundSrc) => {
        let isPlaying = false;
        let audio = document.createElement("audio");
        audio.setAttribute("src", soundSrc);
        let playButon_body = document.createElement("div");
        playButon_body.classList.add("buttonPlayPausePlayPause_wrap");
        playButon_body.classList.add("buttonPlayPause--play");
        playButon_body.style.position = 'relative'
        playButon_body.style.left = 0
        playButon_body.style.top = 0
        let playButon_one = document.createElement("div");
        playButon_one.classList.add("buttonPlayPause__shape");
        playButon_one.classList.add("buttonPlayPause__shape--one");
        let playButon_two = document.createElement("div");
        playButon_two.classList.add("buttonPlayPause__shape");
        playButon_two.classList.add("buttonPlayPause__shape--two");
        playButon_body.append(playButon_one, playButon_two);
        playButon_body.addEventListener("click", function (e) {
            isPlaying ? audio.pause() : audio.play();
            e.target.classList.toggle("buttonPlayPause--active");
            audio.onplaying = function () {
                isPlaying = true;
            };
            audio.onpause = function () {
                isPlaying = false;
            };
            audio.onended = function () {
                e.target.classList.remove("buttonPlayPause--active");
                isPlaying = false;
            };
        });
        return playButon_body;
    };

    data.forEach(item => {
        let id = `${item.text}${Id}`
        let div = document.createElement('div')
        div.classList.add('singleChoice_inputWrapper')
        let input = document.createElement('input')
        input.type = 'radio'
        input.value = item.text
        input.name = Id
        input.id = id
        let label = document.createElement('label')
        label.setAttribute('for', id)
        label.innerText = item.text
        div.append(input)
        if (item.audio) {
            div.append(playSoundsButon(item.audio))
        }
        div.append(label)
        field.append(div)
    });


    let inputs = task.querySelectorAll('input')
    inputs.forEach(item => {
        item.addEventListener('change', changeAnswer)
    })

    function changeAnswer(e) {
        answer = e.target.value
    }

    function sizeCount() {
        let divs = task.querySelectorAll('.singleChoice_inputWrapper')
        let size = 0
        divs.forEach(item => {
            if (item.getBoundingClientRect().width > size) {
                size = item.getBoundingClientRect().width
            }
        })
        field.style.width = `${size}px`
    }

    sizeCount()

    checkingTaskBtn.addEventListener('click', () => {
        if (answer === rightAnswer) {
            chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128516;&nbsp;&nbsp;Молодец!</div>';
            checkTask.classList.add('chek_answer_rightChoice_color');
            checkTask.classList.remove('chek_answer_wrongChoice_color');
        } else {
            chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128528;&nbsp;&nbsp;Попробуй&nbsp;еще!</div>';
            checkTask.classList.add('chek_answer_wrongChoice_color');
            checkTask.classList.remove('chek_answer_rightChoice_color');
        }
    })
    reloadTaskBtn.addEventListener('click', () => {
        inputs.forEach(item => {
            item.checked = 0
        })
        answer = null
        checkTask.classList.remove('chek_answer_rightChoice_color');
        checkTask.classList.remove('chek_answer_wrongChoice_color');
        chek_answerTxt.firstElementChild !== null && chek_answerTxt.removeChild(chek_answerTxt.firstElementChild);

    })

}