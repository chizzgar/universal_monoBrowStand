//ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ ЗВУК + ТЕКСТ

(() => {
  // массив входящих вариантов ответа(звуков) (максимум 5-6 элементов),
  // поле title заполняется по необходимости, если надписи у звука нет, то ставится ''
  // поле id должно быть уникальным, по нему происходит воспроизведение звуков
  // в поле tag заполняется принадлежность к правильному/неправильному ответу, правильное значение указывается ниже
  const arrayOfElements = [
    {
      id: 1,
      title: "Зонтиков больше, чем дождевиков.",
      audioSrc: "sound/singleChoice_4/005.mp3",
      tag: "wrong",
    },
    {
      id: 2,
      title: "Зонтиков меньше, чем дождевиков.",
      audioSrc: "sound/singleChoice_4/006.mp3",
      tag: "wrong",
    },
    {
      id: 3,
      title: "Дождевиков больше, чем зонтиков.",
      audioSrc: "sound/singleChoice_4/007.mp3",
      tag: "wrong",
    },
    {
      id: 4,
      title: "Дождевиков меньше, чем зонтиков.",
      audioSrc: "sound/singleChoice_4/008.mp3",
      tag: "wrong",
    },
    {
      id: 5,
      title: "Зонтиков столько, сколько дождевиков. Их поровну.",
      audioSrc: "sound/singleChoice_4/009.mp3",
      tag: "right",
    },
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "right";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-1");

  // сама функция, которая запускается, здесь ничего менять не нужно
  rendersingleChoiceSoundMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();

//ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ ТОЛЬКО ЗВУК
(() => {
  // массив входящих вариантов ответа(звуков) (максимум 5-6 элементов),
  // поле title заполняется по необходимости, если надписи у звука нет, то ставится ''
  // поле id должно быть уникальным, по нему происходит воспроизведение звуков
  // в поле tag заполняется принадлежность к правильному/неправильному ответу, правильное значение указывается ниже
  const arrayOfElements = [
    {
      id: 1,
      title: "",
      audioSrc: "sound/singleChoice_4/moroz.mp3",
      tag: "wrong",
    },
    {
      id: 2,
      title: "",
      audioSrc: "sound/singleChoice_4/ulibka.mp3",
      tag: "wrong",
    },
    {
      id: 3,
      title: "",
      audioSrc: "sound/singleChoice_4/umka.mp3",
      tag: "right",
    }
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "right";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-2");

  // сама функция, которая запускается, здесь ничего менять не нужно
  rendersingleChoiceSoundMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();

function rendersingleChoiceSoundMarkup(
  arrayOfElements,
  rightAnswer,
  taskWrapper
) {
  let currentSound;
  let currentActiveCard;
  let isPlaying = false;

  const arrayLength = arrayOfElements.length;

  const listContainer = taskWrapper.querySelector(".singleChoiceSoundList");
  const btnReset = taskWrapper.querySelector(".resetButton");
  const btnTest = taskWrapper.querySelector(".checkButton");

  const controlsBox = taskWrapper.querySelector(".show-answer-controls");
  const infoBox = taskWrapper.querySelector(".show-answer-info");

  const cardsMarkup = createPictureCardsMarkup(
    shuffleCards([...arrayOfElements])
  );

  listContainer.insertAdjacentHTML("beforeend", cardsMarkup);

  listContainer.addEventListener("click", onListItemClick);

  btnReset.addEventListener("click", onBtnResetClick);
  btnTest.addEventListener("click", onBtnTestClick);

  const audioFiles = document.querySelectorAll(`.sc-4_audio`);

  [...audioFiles].forEach((el) =>
    el.addEventListener("ended", (e) => {
      e.target
        .closest(".buttonPlayPausePlayPause_wrap")
        .classList.remove("buttonPlayPause--active");
      isPlaying = true;
      resetSound(currentSound);
    })
  );

  function onBtnResetClick(e) {
    removeActiveCardClass(currentActiveCard);
    removeActiveSoundCardClass();
    if (currentActiveCard) {
      currentActiveCard.classList.remove("wrongChoice_answered");
      currentActiveCard.classList.remove("rightChoice_answered");
      currentActiveCard.classList.add("singleChoiceSoundItem_contur");
    }

    listContainer.addEventListener("click", onListItemClick);
    resetSound(currentSound);

    checkingAnswerReset();
    currentActiveCard = null;
  }

  function onBtnTestClick(e) {
    if (!currentActiveCard) {
      checkingAnswerNegative();

      return;
    }

    if (currentActiveCard && currentActiveCard.dataset.name === rightAnswer) {
      addRightChoiceClass(currentActiveCard);
      checkingAnswerPositive();
    } else {
      addWrongChoiceClass(currentActiveCard);
      checkingAnswerNegative();
    }

    removeActiveCardClass(currentActiveCard);
    currentActiveCard.classList.remove("singleChoiceSoundItem_contur");

    listContainer.removeEventListener("click", onListItemClick);
  }

  function createPictureCardsMarkup(pictures) {
    return pictures
      .map((picture) => {
        let widthItem;
        if (picture.title) {
          if (arrayLength > 4) {
            widthItem = `"width: calc(100% / 3 - 10px)"`;
          } else if (arrayLength < 4) {
            widthItem = `"width: calc(100% / ${arrayLength} - 10px)"`;
          } else if (arrayLength === 4) {
            widthItem = `"width: calc(100% / 2 - 10px)"`;
          }
        } else widthItem = `"width: calc(100% / ${arrayLength} - 10px)"`;

        const isTitle =
          picture.title &&
          `<div class='singleChoiceSoundTitle'>${picture.title}</div>`;

        const soundImgWidth = picture.title
          ? ""
          : "singleChoiceSoundSoundImg_big";

        return `
                  <div class="singleChoiceSoundItem singleChoiceSoundItem_contur oneMultiChoice_border" data-name=${picture.tag} style=${widthItem}>
                  <div class="buttonPlayPausePlayPause_wrap buttonPlayPause--play ${soundImgWidth}" sound-data="${picture.id}">
                      <div class="buttonPlayPause__shape buttonPlayPause__shape--one"></div>
                      <div class="buttonPlayPause__shape buttonPlayPause__shape--two"></div>
                        <audio class="sc-4_audio" id=${picture.id} src=${picture.audioSrc}>Your browser does not support the <code>audio</code> element.
                       </audio>
                  </div>
                  ${isTitle}
                  </div>
                  `;
      })
      .join("");
  }

  function onListItemClick(e) {
    let imgEl;

    const isImgEl =
      e.target.classList.contains("singleChoiceSoundTitle") ||
      e.target.classList.contains("buttonPlayPausePlayPause_wrap") ||
      e.target.classList.contains("singleChoiceSoundItem");

    if (!isImgEl) {
      return;
    }

    if (e.target.classList.contains("singleChoiceSoundTitle")) {
      imgEl = e.target.parentElement;
    } else imgEl = e.target;

    if (imgEl.classList.contains("targetChoice_color")) {
      imgEl.classList.remove("targetChoice_color");
    } else if (imgEl.classList.contains("singleChoiceSoundItem")) {
      removeActiveCardClass(currentActiveCard);
      removeActiveSoundCardClass();
      addCheckClass(imgEl);
      resetSound(currentSound);
    }

    if (e.target.classList.contains("buttonPlayPausePlayPause_wrap")) {
      findSoundAndPlayPause("sound-data", e.target);
    }
  }
  function findSoundAndPlayPause(attrName, target) {
    const findedSound = [...audioFiles].find(
      (el) => el.id === target.attributes.getNamedItem(attrName).value
    );

    if (currentSound && currentSound.id === findedSound.id && !isPlaying) {
      currentSound.pause();
      isPlaying = true;
      removeActiveSoundCardClass();

      target.classList.remove("buttonPlayPause--active");
    } else if (
      currentSound &&
      currentSound.id === findedSound.id &&
      isPlaying
    ) {
      currentSound.play();
      isPlaying = false;

      target.classList.add("buttonPlayPause--active");
    } else {
      removeActiveSoundCardClass();

      target.classList.add("buttonPlayPause--active");
      resetSound(currentSound);
      isPlaying = false;

      currentSound = findedSound;
      currentSound.play();
    }
  }

  function addCheckClass(card) {
    card.classList.add("targetChoice_color");
    currentActiveCard = getActiveCard();
  }
  function addRightChoiceClass(card) {
    card.classList.add("rightChoice_answered");
  }
  function addWrongChoiceClass(card) {
    card.classList.add("wrongChoice_answered");
  }

  function removeActiveCardClass(currentActiveCard) {
    if (currentActiveCard) {
      currentActiveCard.classList.remove("targetChoice_color");
    }
  }

  function removeActiveSoundCardClass() {
    const currentActiveSound = taskWrapper.querySelector(
      ".buttonPlayPausePlayPause_wrap.buttonPlayPause--active"
    );

    if (currentActiveSound) {
      currentActiveSound.classList.remove("buttonPlayPause--active");
    }
  }

  function getActiveCard() {
    return taskWrapper.querySelector(
      ".singleChoiceSoundItem.targetChoice_color"
    );
  }

  function checkingAnswerPositive() {
    controlsBox.classList.add("chek_answer_rightChoice_color");
    infoBox.innerHTML =
      '<div class="answer_indicator">&#128516;&nbsp;&nbsp;Молодец!</div>';
  }
  function checkingAnswerNegative() {
    controlsBox.classList.add("chek_answer_wrongChoice_color");

    infoBox.innerHTML =
      '<div class="answer_indicator">&#128528;&nbsp;&nbsp;Попробуй&nbsp;еще!</div>';
  }
  function checkingAnswerReset() {
    controlsBox.classList.remove("chek_answer_wrongChoice_color");
    controlsBox.classList.remove("chek_answer_rightChoice_color");

    infoBox.firstElementChild !== null &&
      infoBox.removeChild(infoBox.firstElementChild);
  }

  function resetSound(currentSound) {
    if (currentSound) {
      currentSound.pause();
      currentSound.currentTime = 0;
      currentSound = null;
    }
  }
  function shuffleCards(array) {
    const length = array.length;
    for (let i = length; i > 0; i--) {
      const randomIndex = Math.floor(Math.random() * i);
      const currentIndex = i - 1;
      const temp = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temp;
    }
    return array;
  }
}
