(() => {
  // массив входящих звуков (минимум 4, максимум 6 элементов),

  //в поле tag заполняется принадлежность к правильному/неправильному ответу

  const arrayOfElements = [
    {
      id: 1,
      tag: "right",
      videoSrc: "media/mc-video/fly_ship_360p.mp4",
      text: ''
    },
    {
      id: 2,
      videoSrc: "media/mc-video/pes_360p.mp4",
      tag: "wrong",
      text: ''
    },
    {
      id: 3,
      videoSrc: "media/mc-video/sneg_360p.mp4",
      tag: "wrong",
      text: ''
    }
  ];
  // здесь указывается правильный ответ, он проверяется по полю name  в массиве
  const rightAnswer = "right";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("singleChoice_5_task-1");

  // сама функция, которая запускается, здесь ничего менять не нужно
  renderMultipleChoiceVideoMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();

(() => {
  // массив входящих звуков (минимум 4, максимум 6 элементов),

  //в поле tag заполняется принадлежность к правильному/неправильному ответу

  const arrayOfElements = [
    {
      id: 1,
      tag: "many",
      videoSrc: "media/mc-video/DOH_3-4_31_3_1.mp4",
      text: ''
    },
    {
      id: 2,
      videoSrc: "media/mc-video/DOH_3-4_31_3_2.mp4",
      tag: "one",
      text: ''

    },
    {
      id: 3,
      videoSrc: "media/mc-video/DOH_3-4_31_3_3.mp4",
      tag: "one",
      text: ''

    },
    {
      id: 4,
      videoSrc: "media/mc-video/DOH_3-4_31_3_4.mp4",
      tag: "one",
      text: ''

    },
    {
      id: 4,
      videoSrc: "media/mc-video/DOH_3-4_31_3_4.mp4",
      tag: "one",
      text: ''

    },
    {
      id: 4,
      videoSrc: "media/mc-video/DOH_3-4_31_3_4.mp4",
      tag: "one",
      text: ''

    },
  ];
  // здесь указывается правильный ответ, он проверяется по полю name  в массиве
  const rightAnswer = "many";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("singleChoice_5_task-2");

  // сама функция, которая запускается, здесь ничего менять не нужно
  renderMultipleChoiceVideoMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();


function renderMultipleChoiceVideoMarkup(
  arrayOfElements,
  rightAnswer,
  taskWrapper
) {
  const arrayLength = arrayOfElements.length;
  const rightAnswersLength = arrayOfElements.filter(
    (el) => el.tag === rightAnswer
  ).length;

  const listContainer = taskWrapper.querySelector(".singleChoice_5_List");
  const reloadTaskBtn = taskWrapper.querySelector('.reloadTask')
  const checkingTaskBtn = taskWrapper.querySelector('.checkingTask')
  const chek_answerTxt = taskWrapper.querySelector('.chek_answer')
  const checkTask = taskWrapper.querySelector('.checkTask');
  

  listContainer.insertAdjacentHTML(
    "beforeend",
    createPictureCardsMarkup(shuffleCards([...arrayOfElements]))
  );

  listContainer.addEventListener("click", matchingHandler);
  reloadTaskBtn.addEventListener("click", onBtnResetClick);
  checkingTaskBtn.addEventListener("click", onBtnTestClick);

  function shuffleCards(array) {
    const length = array.length;
    for (let i = length; i > 0; i--) {
      const randomIndex = Math.floor(Math.random() * i);
      const currentIndex = i - 1;
      const temp = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temp;
    }
    return array;
  }

  function createPictureCardsMarkup(pictures) {
    return pictures
      .map((item) => {
        let widthItem;
        let heightItem;

        if (arrayLength <= 4 && arrayLength <= 6) {
          widthItem = `"width: calc(100% / 2 - 10px)"`;
          heightItem = "singleChoice_5_Card_middle";
        } else if (arrayLength === 6) {
          widthItem = `"width: calc(100% / 2 - 10px)"`;
          heightItem = "singleChoice_5_Card_big";
        }
        const isText =
        item.text && `<div class="singleChoice_5_CardText" style="text-align: center">${item.text}</div>`


        return `<div class="singleChoice_5_Card oneMultiChoice_border ${heightItem}" data=${item.tag} style=${widthItem}>
                    <video class="singleChoice_5_" controls
                           src=${item.videoSrc}
                           id=${item.id}
                           type="video/mp4"
                    >
                    </video>
                    ${isText}
                </div>`;
      })
      .join("");
  }

  function onBtnResetClick() {
    removeAllActiveClasses();
    checkingAnswerReset();
    listContainer.addEventListener("click", matchingHandler);
  }

  function onBtnTestClick() {
    let winCount = 0;

    const selectedItems = [...listContainer.children].filter((el) =>
      el.classList.contains("targetChoice_color")
    );
    removeAllActiveClasses()
    selectedItems.forEach((item) => {
      if (item.attributes.getNamedItem("data").value === rightAnswer) {
        winCount += 1;
        
        addRightChoiceClass(item);
      } else {
        winCount -= 1;
        addWrongChoiceClass(item);
      }
    });
    if (winCount === rightAnswersLength) {
      checkingAnswerPositive();
    } else checkingAnswerNegative();
    
    listContainer.removeEventListener("click", matchingHandler);
  }

  function matchingHandler(e) {
    let matchedItem;
    const isImgEl =
      e.target.classList.contains("singleChoice_5_Card") ||
      e.target.classList.contains("singleChoice_5_")||
      e.target.classList.contains("singleChoice_5_CardText");

    if (!isImgEl) {
      return;
    }

    if (e.target.classList.contains("singleChoice_5_Card")) {
      matchedItem = e.target;
    }else if(e.target.classList.contains("singleChoice_5_CardText")){
      matchedItem = e.target.parentElement;

    }

    if (matchedItem) {
      removeAllActiveClasses()
        addCheckClass(matchedItem);
    
    }
  }

  function addCheckClass(card) {
    card.classList.add("targetChoice_color");
  }

  function addRightChoiceClass(card) {
    card.classList.add("rightChoice_answered");
  }

  function addWrongChoiceClass(card) {
    card.classList.add("wrongChoice_answered");
  }

  function removeAllActiveClasses() {
    const currentActiveCards = taskWrapper.querySelectorAll(
      ".singleChoice_5_Card"
    );

    if (currentActiveCards.length > 0) {
      currentActiveCards.forEach((item) => {
        item.classList.remove("targetChoice_color");
        item.classList.remove("rightChoice_answered");
        item.classList.remove("wrongChoice_answered");
       
      });
    }
  }

  function checkingAnswerPositive() {
    chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128516;&nbsp;&nbsp;Молодец!</div>';
            checkTask.classList.add('chek_answer_rightChoice_color');
            checkTask.classList.remove('chek_answer_wrongChoice_color');
  }
  function checkingAnswerNegative() {
    chek_answerTxt.innerHTML = '<div class="answer_indicator">&#128528;&nbsp;&nbsp;Попробуй&nbsp;еще!</div>';
    checkTask.classList.add('chek_answer_wrongChoice_color');
    checkTask.classList.remove('chek_answer_rightChoice_color');
    }
  function checkingAnswerReset() {
    checkTask.classList.remove('chek_answer_rightChoice_color');
    checkTask.classList.remove('chek_answer_wrongChoice_color');
    chek_answerTxt.firstElementChild !== null && chek_answerTxt.removeChild(chek_answerTxt.firstElementChild);


  }
}
