// ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ КАРТИНКА + ЗВУК + ТЕКСТ

(() => {
  // массив входящих картинок (максимум 5-6 элементов),
  // поле title, audioSrc  заполняется по необходимости, если надписи или звука нет, то ставится ''
  // в поле tag указывается уникальное слово или цифра, по которой будет сверяться правильный ответ
  // в поле id указывается уникальное слово или цифра, по которым воспроизводятся звуки

  const arrayOfElements = [
    {
      id: 1,
      name: "bear",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_1.jpg",
      title: "Медведь",
      audioSrc: "sound/singleChoice_3/bear.mp3",
      tag: "bear",
    },
    {
      id: 2,
      name: "fox",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_2.jpg",
      title: "Лиса",
      audioSrc: "sound/singleChoice_3/fox.mp3",
      tag: "fox",
    },
    {
      id: 3,
      name: "wolf",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_3.jpg",
      title: "Волк",
      audioSrc: "sound/singleChoice_3/wolf.mp3",
      tag: "wolf",
    },
    {
      id: 4,
      name: "squirrel",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_4.jpg",
      title: "Белка",
      audioSrc: "sound/singleChoice_3/squirrel.mp3",
      tag: "squirrel",
    },
    {
      id: 5,
      name: "monkey",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_5.jpg",
      title: "Обезьяна",
      audioSrc: "sound/singleChoice_3/monkey.mp3",
      tag: "monkey",
    },
    {
      id: 6,
      name: "giraffe",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_6.jpg",
      title: "Жираф",
      audioSrc: "sound/singleChoice_3/giraffe.mp3",
      tag: "giraffe",
    },
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "bear";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-1");

  // сама функция, которая запускается, здесь ничего менять не нужно

  rendersingleChoiceSoundImgMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();
// ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ ТОЛЬКО КАРТИНКА И ЗВУК

(() => {
  // массив входящих картинок (максимум 5-6 элементов),
  // поле title, audioSrc  заполняется по необходимости, если надписи или звука нет, то ставится ''
  // в поле tag указывается уникальное слово или цифра, по которой будет сверяться правильный ответ
  // в поле id указывается уникальное слово или цифра, по которым воспроизводятся звуки
  const arrayOfElements = [
    {
      id: 1,
      name: "bear",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_1.jpg",
      title: "",
      audioSrc: "sound/singleChoice_3/bear.mp3",
      tag: "bear",
    },
    {
      id: 2,
      name: "fox",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_2.jpg",
      title: "",
      audioSrc: "sound/singleChoice_3/fox.mp3",
      tag: "fox",
    },
    {
      id: 3,
      name: "wolf",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_3.jpg",
      title: "",
      audioSrc: "sound/singleChoice_3/wolf.mp3",
      tag: "wolf",
    },
    {
      id: 4,
      name: "squirrel",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_4.jpg",
      title: "",
      audioSrc: "sound/singleChoice_3/squirrel.mp3",
      tag: "squirrel",
    },
    // {
    //   id: 5,
    //   name: "monkey",
    //   src: "Images_1/singleChoice_3/DO_3-4_21_5_5.jpg",
    //   title: "",
    //   audioSrc: "sound/singleChoice_3/monkey.mp3",
    //   tag: "monkey",
    // },
    // {
    //   id: 6,
    //   name: "giraffe",
    //   src: "Images_1/singleChoice_3/DO_3-4_21_5_6.jpg",
    //   title: "",
    //   audioSrc: "sound/singleChoice_3/giraffe.mp3",
    //   tag: "giraffe",
    // },
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "bear";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-2");

  // сама функция, которая запускается, здесь ничего менять не нужно

  rendersingleChoiceSoundImgMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();
// ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ ТОЛЬКО КАРТИНКА

(() => {
  // массив входящих картинок (максимум 5-6 элементов),
  // поле title, audioSrc  заполняется по необходимости, если надписи или звука нет, то ставится ''
  // в поле tag указывается уникальное слово или цифра, по которой будет сверяться правильный ответ
  // в поле id указывается уникальное слово или цифра, по которым воспроизводятся звуки
  const arrayOfElements = [
    {
      id: 1,
      name: "lion",
      src: "Images_1/singleChoice_3/lion.dbd8c13b.png",
      title: "",
      audioSrc: "",
      tag: "lion",
    },
    {
      id: 2,
      name: "monkey",
      src: "Images_1/singleChoice_3/monkey.0cf4077b.png",
      title: "",
      audioSrc: "",
      tag: "monkey",
    },
    {
      id: 2,
      name: "tiger",
      src: "Images_1/singleChoice_3/tiger.7bc5058d.png",
      title: "",
      audioSrc: "",
      tag: "tiger",
    },
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "monkey";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-3");

  // сама функция, которая запускается, здесь ничего менять не нужно
  rendersingleChoiceSoundImgMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();
// ВЫЗОВ ФУНКЦИИ ДЛЯ СЛУЧАЯ ТОЛЬКО КАРТИНКА + НАДПИСЬ

(() => {
  // массив входящих картинок (максимум 5-6 элементов),
  // поле title, audioSrc  заполняется по необходимости, если надписи или звука нет, то ставится ''
  // в поле tag указывается уникальное слово или цифра, по которой будет сверяться правильный ответ
  // в поле id указывается уникальное слово или цифра, по которым воспроизводятся звуки
  const arrayOfElements = [
    {
      id: 1,
      name: "bear",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_1.jpg",
      title: "Медведь",
      audioSrc: "",
      tag: "bear",
    },
    {
      id: 2,
      name: "fox",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_2.jpg",
      title: "Лиса",
      audioSrc: "",
      tag: "fox",
    },
    {
      id: 3,
      name: "wolf",
      src: "Images_1/singleChoice_3/DO_3-4_21_5_3.jpg",
      title: "Волк",
      audioSrc: "",
      tag: "wolf",
    },
    // {
    //   id: 4,
    //   name: "squirrel",
    //   src: "Images_1/singleChoice_3/DO_3-4_21_5_4.jpg",
    //   title: "Белка",
    //   audioSrc: "",
    //   tag: "squirrel",
    // },
    // {
    //   id: 5,
    //   name: "monkey",
    //   src: "Images_1/singleChoice_3/DO_3-4_21_5_5.jpg",
    //   title: "Обезьяна",
    //   audioSrc: "sound/singleChoice_3/monkey.mp3",
    //   tag: "monkey",
    // },
    // {
    //   id: 6,
    //   name: "giraffe",
    //   src: "Images_1/singleChoice_3/DO_3-4_21_5_6.jpg",
    //   title: "Жираф",
    //   audioSrc: "sound/singleChoice_3/giraffe.mp3",
    //   tag: "giraffe",
    // },
  ];

  // здесь указывается правильный ответ, он проверяется по полю tag  в массиве
  const rightAnswer = "bear";

  // это контейнер для данного задания, для каждого нужно будет вписывать свой id, который был присвоен в html
  const taskWrapper = document.getElementById("task-4");

  // сама функция, которая запускается, здесь ничего менять не нужно
  rendersingleChoiceSoundImgMarkup(arrayOfElements, rightAnswer, taskWrapper);
})();

// НИЖЕ САМА ФУНКЦИЯ
function rendersingleChoiceSoundImgMarkup(
  arrayOfElements,
  rightAnswer,
  taskWrapper
) {
  let currentSound;
  let currentActiveCard;
  let isPlaying = false;

  const arrayLength = arrayOfElements.length;

  const listContainer = taskWrapper.querySelector(".singleChoiceSoundImgList");
  const btnReset = taskWrapper.querySelector(".resetButton");
  const btnTest = taskWrapper.querySelector(".checkButton");

  const controlsBox = taskWrapper.querySelector(".show-answer-controls");
  const infoBox = taskWrapper.querySelector(".show-answer-info");

  const cardsMarkup = createPictureCardsMarkup(
    shuffleCards([...arrayOfElements])
  );

  listContainer.insertAdjacentHTML("beforeend", cardsMarkup);

  listContainer.addEventListener("click", onListItemClick);

  btnReset.addEventListener("click", onBtnResetClick);
  btnTest.addEventListener("click", onBtnTestClick);

  const audioFiles = taskWrapper.querySelectorAll(".sc_3-audio");

  [...audioFiles].forEach((el) =>
    el.addEventListener("ended", (e) => {
      e.target
        .closest(".buttonPlayPausePlayPause_wrap")
        .classList.remove("buttonPlayPause--active");
      isPlaying = true;
      resetSound(currentSound);
    })
  );

  function onBtnResetClick(e) {
    removeActiveCardClass(currentActiveCard);
    removeActiveSoundCardClass();
    if (currentActiveCard) {
      currentActiveCard.classList.remove("wrongChoice_answered");
      currentActiveCard.classList.remove("rightChoice_answered");
      currentActiveCard.classList.add("singleChoiceSoundImgItem_contur");
    }

    listContainer.addEventListener("click", onListItemClick);
    resetSound(currentSound);

    checkingAnswerReset();
    currentActiveCard = null;
  }

  function onBtnTestClick(e) {
    if (!currentActiveCard) {
      checkingAnswerNegative();
      return;
    }

    if (currentActiveCard && currentActiveCard.dataset.name === rightAnswer) {
      addRightChoiceClass(currentActiveCard);
      checkingAnswerPositive();
    } else {
      addWrongChoiceClass(currentActiveCard);
      checkingAnswerNegative();
    }
    removeActiveCardClass(currentActiveCard);
    currentActiveCard.classList.remove("singleChoiceSoundImgItem_contur");

    listContainer.removeEventListener("click", onListItemClick);
  }

  function createPictureCardsMarkup(pictures) {
    return pictures
      .map((picture) => {
        let widthItem;
        if (arrayLength > 4) {
          widthItem = `"width: calc(100% / 3 - 10px)"`;
        } else if (arrayLength < 4) {
          widthItem = `"width: calc(100% / ${arrayLength} - 10px)"`;
        } else if (arrayLength === 4) {
          widthItem = `"width: calc(100% / 2 - 10px)"`;
        }
        const isTitle =
          picture.title &&
          `<div class='singleChoiceSoundImgTitle'>${picture.title}</div>`;
        const isSound =
          picture.audioSrc &&
          `<div class='singleChoiceSoundImgSoundImg' sound-data="${picture.id}">
                <div class="buttonPlayPausePlayPause_wrap buttonPlayPause--play">
                    <div class="buttonPlayPause__shape buttonPlayPause__shape--one"></div>
                    <div class="buttonPlayPause__shape buttonPlayPause__shape--two"></div>
                    <audio class="sc_3-audio" id="${picture.id}" src="${picture.audioSrc}">
                              Your browser does not support the
                              <code>audio</code> element.
                    </audio>
                </div>
            </div>`;

        return `
                <div class="singleChoiceSoundImgItem oneMultiChoice_border singleChoiceSoundImgItem_contur" data-name=${picture.tag} style=${widthItem}>
                    <div class='singleChoiceSoundImgImageBox' style="background-image: url(${picture.src})">
                       <div class="zoom_open_button_white sc_3-enlarge_picture" title="Увеличить картинку">
                          <div class="icon_zoomPicture whiteZoomImg"></div>
                       </div>
                    </div>
                    ${isSound}
                    ${isTitle}
                    </div>
                    `;
      })
      .join("");
  }

  function onListItemClick(e) {
    let imgEl;
    if (e.target.classList.contains("sc_3-enlarge_picture")) {
      scaleImage(e.target.parentElement);
    }
    const isImgEl =
      e.target.classList.contains("singleChoiceSoundImgImageBox") ||
      e.target.classList.contains("singleChoiceSoundImgTitle") ||
      e.target.classList.contains("buttonPlayPausePlayPause_wrap") ||
      e.target.classList.contains("singleChoiceSoundImgItem");

    if (!isImgEl) {
      return;
    }

    if (
      e.target.classList.contains("singleChoiceSoundImgImageBox") ||
      e.target.classList.contains("singleChoiceSoundImgTitle")
    ) {
      imgEl = e.target.parentElement;
    } else imgEl = e.target;

    if (imgEl.classList.contains("targetChoice_color")) {
      imgEl.classList.remove("targetChoice_color");
    } else if (imgEl.classList.contains("singleChoiceSoundImgItem")) {
      removeActiveCardClass(currentActiveCard);
      removeActiveSoundCardClass();

      addCheckClass(imgEl);

      resetSound(currentSound);
    }

    if (e.target.classList.contains("buttonPlayPausePlayPause_wrap")) {
      findSoundAndPlayPause("sound-data", e.target);
    }
  }

  function findSoundAndPlayPause(attrName, target) {
    const findedSound = [...audioFiles].find(
      (el) =>
        el.id === target.parentElement.attributes.getNamedItem(attrName).value
    );

    if (currentSound && currentSound.id === findedSound.id && !isPlaying) {
      currentSound.pause();
      isPlaying = true;
      removeActiveSoundCardClass();

      target.classList.remove("buttonPlayPause--active");
    } else if (
      currentSound &&
      currentSound.id === findedSound.id &&
      isPlaying
    ) {
      currentSound.play();
      isPlaying = false;

      target.classList.add("buttonPlayPause--active");
    } else {
      removeActiveSoundCardClass();

      target.classList.add("buttonPlayPause--active");
      resetSound(currentSound);
      isPlaying = false;

      currentSound = findedSound;
      currentSound.play();
    }
  }

  function addCheckClass(card) {
    card.classList.add("targetChoice_color");
    currentActiveCard = getActiveCard();
  }
  function addRightChoiceClass(card) {
    card.classList.add("rightChoice_answered");
  }
  function addWrongChoiceClass(card) {
    card.classList.add("wrongChoice_answered");
  }

  function removeActiveCardClass(currentActiveCard) {
    if (currentActiveCard) {
      currentActiveCard.classList.remove("targetChoice_color");
    }
  }

  function removeActiveSoundCardClass() {
    const currentActiveSound = document.querySelector(
      ".buttonPlayPausePlayPause_wrap.buttonPlayPause--active"
    );

    if (currentActiveSound) {
      currentActiveSound.classList.remove("buttonPlayPause--active");
    }
  }

  function getActiveCard() {
    return taskWrapper.querySelector(
      ".singleChoiceSoundImgItem.targetChoice_color"
    );
  }
  function resetSound(currentSound) {
    if (currentSound) {
      currentSound.pause();
      currentSound.currentTime = 0;
      currentSound = null;
    }
  }

  function checkingAnswerPositive() {
    controlsBox.classList.add("chek_answer_rightChoice_color");
    infoBox.innerHTML =
      '<div class="answer_indicator">&#128516;&nbsp;&nbsp;Молодец!</div>';
  }
  function checkingAnswerNegative() {
    controlsBox.classList.add("chek_answer_wrongChoice_color");

    infoBox.innerHTML =
      '<div class="answer_indicator">&#128528;&nbsp;&nbsp;Попробуй&nbsp;еще!</div>';
  }
  function checkingAnswerReset() {
    controlsBox.classList.remove("chek_answer_wrongChoice_color");
    controlsBox.classList.remove("chek_answer_rightChoice_color");

    infoBox.firstElementChild !== null &&
      infoBox.removeChild(infoBox.firstElementChild);
  }

  function shuffleCards(array) {
    const length = array.length;
    for (let i = length; i > 0; i--) {
      const randomIndex = Math.floor(Math.random() * i);
      const currentIndex = i - 1;
      const temp = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temp;
    }
    return array;
  }
  function scaleImage(targetEl) {
    let modal = document.createElement("div");
    modal.style.position = "fixed";
    modal.style.left = 0;
    modal.style.top = 0;
    modal.style.bottom = 0;
    modal.style.right = 0;
    modal.style.background = "rgba(0,0,0,0.5)";
    modal.style.zIndex = 100;
    modal.style.display = "flex";
    modal.style.justifyContent = "center";
    modal.style.flexDirection = "column";
    modal.style.alignItems = "center";

    let div = document.createElement("div");
    div.style.width = "50%";
    div.style.height = "80%";
    div.style.textAlign = "center";
    let img = document.createElement("img");
    if (targetEl.tagName === "IMG") {
      img.src = targetEl.src;
    } else {
      img.src = targetEl.style.backgroundImage.slice(5, -2);
    }
    img.style.maxWidth = "100%";
    img.style.maxHeight = "100%";

    div.append(img);
    modal.append(div);
    let close = document.createElement("div");
    close.classList.add("icon_close_button", "close_icon_white");

    close.style.marginLeft = "calc(100% - 25px)";
    close.style.cursor = "pointer";

    div.append(close);
    document.body.style.overflow = "hidden";

    modal.addEventListener("pointerdown", () => {
      modal.remove();
      document.body.style.overflow = "visible";
    });
    document.body.append(modal);
  }
}
